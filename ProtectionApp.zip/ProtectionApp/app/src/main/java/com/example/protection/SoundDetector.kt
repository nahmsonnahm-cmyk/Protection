package com.example.protection

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Détecteur de bruit fort et soutenu (prototype).
 *
 * Il mesure le volume toutes les 250 ms et le compare au bruit ambiant moyen.
 * Si le volume dépasse l'ambiant de [marginDb] dB pendant au moins 2 mesures sur 4,
 * il appelle [onTrigger]. Aucun son n'est enregistré ni envoyé.
 *
 * V2 : remplacer [analyze] par un modèle TensorFlow Lite (YAMNet) qui reconnaît
 * les cris, le verre brisé, etc.
 */
class SoundDetector(
    private val marginDb: () -> Int,
    private val onTrigger: (levelDb: Double) -> Unit
) {
    @Volatile private var running = false
    private var thread: Thread? = null

    private val sampleRate = 16000
    private val frameSamples = sampleRate / 4 // 250 ms

    private var ambientDb = -60.0
    private var warmup = 8 // ignore les 2 premières secondes
    private val recent = ArrayDeque<Boolean>()
    private var cooldownUntil = 0L

    @SuppressLint("MissingPermission") // permission vérifiée dans MainActivity
    fun start() {
        if (running) return
        running = true
        thread = Thread {
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val bufSize = maxOf(minBuf, frameSamples * 2)
            val rec = AudioRecord(
                MediaRecorder.AudioSource.MIC, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                running = false
                return@Thread
            }
            val buf = ShortArray(frameSamples)
            rec.startRecording()
            try {
                while (running) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n > 0) analyze(buf, n)
                }
            } finally {
                rec.stop()
                rec.release()
            }
        }.also { it.name = "SoundDetector"; it.start() }
    }

    fun stop() {
        running = false
        thread = null
    }

    /** Évite de redéclencher juste après une alerte. */
    fun pauseFor(ms: Long) {
        cooldownUntil = System.currentTimeMillis() + ms
        recent.clear()
    }

    private fun analyze(buf: ShortArray, n: Int) {
        var sum = 0.0
        for (i in 0 until n) {
            val s = buf[i].toDouble()
            sum += s * s
        }
        val rms = sqrt(sum / n)
        val db = 20 * log10((rms + 1.0) / 32768.0) // 0 dB = volume maximal

        if (warmup > 0) {
            warmup--
            ambientDb = if (ambientDb == -60.0) db else 0.7 * ambientDb + 0.3 * db
            return
        }
        if (System.currentTimeMillis() < cooldownUntil) return

        val loud = db > ambientDb + marginDb() && db > -35.0
        recent.addLast(loud)
        if (recent.size > 4) recent.removeFirst()

        if (!loud) {
            // Le bruit ambiant s'adapte lentement : rue calme, marché, etc.
            ambientDb = 0.97 * ambientDb + 0.03 * db
        }

        if (recent.count { it } >= 2) {
            recent.clear()
            onTrigger(db)
        }
    }
}
