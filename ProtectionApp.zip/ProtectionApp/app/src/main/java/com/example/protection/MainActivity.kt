package com.example.protection

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/** Écran unique : contact de confiance, sensibilité, surveillance et bouton SOS. */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var etUser: EditText
    private lateinit var etName: EditText
    private lateinit var etPhone: EditText
    private lateinit var btnToggle: Button
    private lateinit var tvStatus: TextView
    private var afterPermissions: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 14f; setPadding(0, dp(12), 0, 0) }

        root.addView(TextView(this).apply { text = "Protection"; textSize = 28f })

        root.addView(label("Votre prénom (apparaît dans le SMS)"))
        etUser = EditText(this).apply { setText(prefs.userName); inputType = InputType.TYPE_CLASS_TEXT }
        root.addView(etUser)

        root.addView(label("Contact de confiance : nom"))
        etName = EditText(this).apply { setText(prefs.contactName); inputType = InputType.TYPE_CLASS_TEXT }
        root.addView(etName)

        root.addView(label("Contact de confiance : numéro (ex. +2250700000000)"))
        etPhone = EditText(this).apply { setText(prefs.contactPhone); inputType = InputType.TYPE_CLASS_PHONE }
        root.addView(etPhone)

        root.addView(Button(this).apply {
            text = "Enregistrer"
            setOnClickListener { save(); toast("Enregistré") }
        })

        root.addView(label("Sensibilité au bruit (à droite = plus sensible)"))
        root.addView(SeekBar(this).apply {
            max = 20 // marge de 35 dB (peu sensible) à 15 dB (très sensible)
            progress = 35 - prefs.marginDb
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) prefs.marginDb = 35 - p
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        btnToggle = Button(this).apply { setOnClickListener { toggleGuard() } }
        root.addView(btnToggle)

        root.addView(Button(this).apply {
            text = "Désactiver l'optimisation de batterie"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })

        root.addView(Button(this).apply {
            text = "SOS"
            textSize = 36f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#D32F2F"))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(180)
            ).apply { topMargin = dp(24) }
            gravity = Gravity.CENTER
            setOnClickListener { sos() }
        })

        tvStatus = TextView(this).apply { setPadding(0, dp(16), 0, 0) }
        root.addView(tvStatus)

        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun save() {
        prefs.userName = etUser.text.toString().trim()
        prefs.contactName = etName.text.toString().trim()
        prefs.contactPhone = etPhone.text.toString().trim().replace(" ", "")
    }

    private fun toggleGuard() {
        if (GuardService.monitoring) {
            GuardService.send(this, GuardService.ACTION_STOP)
            refreshLater()
            return
        }
        save()
        if (!prefs.hasContact) return toast("Entrez d'abord le numéro du contact.")
        ensurePermissions {
            GuardService.send(this, GuardService.ACTION_START)
            refreshLater()
        }
    }

    private fun sos() {
        save()
        if (!prefs.hasContact) return toast("Entrez d'abord le numéro du contact.")
        ensurePermissions { GuardService.send(this, GuardService.ACTION_SOS) }
    }

    private fun refresh() {
        btnToggle.text = if (GuardService.monitoring) "Arrêter la surveillance" else "Activer la surveillance"
        tvStatus.text = if (GuardService.monitoring) "Surveillance active." else "Surveillance arrêtée."
    }

    private fun refreshLater() = Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 600)

    // ---------- Permissions ----------

    private fun requiredPermissions(): List<String> {
        val p = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.SEND_SMS
        )
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        return p
    }

    private fun ensurePermissions(then: () -> Unit) {
        val missing = requiredPermissions().filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            then()
        } else {
            afterPermissions = then
            requestPermissions(missing.toTypedArray(), 42)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != 42) return
        val essential = listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.SEND_SMS)
        val ok = essential.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        if (ok) afterPermissions?.invoke() else toast("Micro et SMS sont nécessaires.")
        afterPermissions = null
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
