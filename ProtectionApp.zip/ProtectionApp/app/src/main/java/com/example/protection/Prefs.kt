package com.example.protection

import android.content.Context

/** Stockage local simple : contact de confiance et sensibilité. Rien n'est envoyé sur internet. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("protection", Context.MODE_PRIVATE)

    var contactName: String
        get() = sp.getString("name", "") ?: ""
        set(v) = sp.edit().putString("name", v).apply()

    var contactPhone: String
        get() = sp.getString("phone", "") ?: ""
        set(v) = sp.edit().putString("phone", v).apply()

    /** Nom de l'utilisateur, utilisé dans le message d'alerte. */
    var userName: String
        get() = sp.getString("user", "") ?: ""
        set(v) = sp.edit().putString("user", v).apply()

    /** Marge (en dB) au-dessus du bruit ambiant pour déclencher. Plus petit = plus sensible. */
    var marginDb: Int
        get() = sp.getInt("margin", 22)
        set(v) = sp.edit().putInt("margin", v).apply()

    val hasContact: Boolean get() = contactPhone.isNotBlank()
}
