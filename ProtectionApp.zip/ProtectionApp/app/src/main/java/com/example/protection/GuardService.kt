package com.example.protection

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Service au premier plan : écoute le volume sonore, gère le compte à rebours
 * et l'envoi des SMS (alerte + suivi de position).
 */
class GuardService : Service() {

    companion object {
        const val ACTION_START = "com.example.protection.START"
        const val ACTION_STOP = "com.example.protection.STOP"
        const val ACTION_SOS = "com.example.protection.SOS"
        const val ACTION_CANCEL = "com.example.protection.CANCEL"

        private const val CH_STATUS = "status"
        private const val CH_ALERT = "alert"
        private const val ID_STATUS = 1
        private const val ID_ALERT = 2

        private const val NOISE_COUNTDOWN_S = 10
        private const val SOS_COUNTDOWN_S = 5
        private const val FOLLOWUP_COUNT = 5
        private const val FOLLOWUP_EVERY_MS = 120_000L

        @Volatile var monitoring = false

        fun send(ctx: Context, action: String) {
            val i = Intent(ctx, GuardService::class.java).setAction(action)
            ContextCompat.startForegroundService(ctx, i)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var detector: SoundDetector
    private lateinit var prefs: Prefs
    private lateinit var nm: NotificationManager

    private var counting = false
    private var remaining = 0
    private var reason = ""
    private var followUpsLeft = 0

    private val tick = object : Runnable {
        override fun run() {
            remaining--
            if (remaining <= 0) {
                fire()
            } else {
                showCountdown()
                buzz(150)
                handler.postDelayed(this, 1000)
            }
        }
    }

    private val followUp = object : Runnable {
        override fun run() {
            AlertSender.send(this@GuardService, reason, isUpdate = true)
            followUpsLeft--
            if (followUpsLeft > 0) {
                handler.postDelayed(this, FOLLOWUP_EVERY_MS)
            } else if (!monitoring) {
                stopAll()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CH_STATUS, "Protection active", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Alertes", NotificationManager.IMPORTANCE_HIGH)
        )
        detector = SoundDetector({ prefs.marginDb }) {
            handler.post { beginCountdown("bruit fort detecte", NOISE_COUNTDOWN_S) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!enterForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent?.action) {
            ACTION_START -> {
                monitoring = true
                detector.start()
                refreshStatus()
            }
            ACTION_STOP -> stopAll()
            ACTION_SOS -> {
                refreshStatus()
                beginCountdown("bouton SOS", SOS_COUNTDOWN_S)
            }
            ACTION_CANCEL -> cancelAlert()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        detector.stop()
        monitoring = false
        super.onDestroy()
    }

    // ---------- Compte à rebours et envoi ----------

    private fun beginCountdown(why: String, seconds: Int) {
        if (counting) return
        counting = true
        reason = why
        remaining = seconds
        showCountdown()
        buzz(400)
        handler.postDelayed(tick, 1000)
    }

    private fun cancelAlert() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(followUp)
        counting = false
        nm.cancel(ID_ALERT)
        detector.pauseFor(30_000)
        if (!monitoring) stopAll()
    }

    private fun fire() {
        counting = false
        val ok = AlertSender.send(this, reason)
        detector.pauseFor(60_000)
        val text = if (ok) "Alerte envoyée à ${prefs.contactName.ifBlank { "votre contact" }}."
        else "Échec de l'envoi : vérifiez le contact et l'autorisation SMS."
        nm.notify(
            ID_ALERT,
            NotificationCompat.Builder(this, CH_ALERT)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("Alerte")
                .setContentText(text)
                .addAction(0, "Je vais bien (arrêter le suivi)", servicePi(ACTION_CANCEL))
                .setOngoing(ok)
                .build()
        )
        if (ok) {
            followUpsLeft = FOLLOWUP_COUNT
            handler.postDelayed(followUp, FOLLOWUP_EVERY_MS)
        } else if (!monitoring) {
            stopAll()
        }
    }

    private fun stopAll() {
        handler.removeCallbacksAndMessages(null)
        detector.stop()
        monitoring = false
        nm.cancel(ID_ALERT)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------- Notifications ----------

    private fun enterForeground(): Boolean {
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED
        ) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        return try {
            ServiceCompat.startForeground(this, ID_STATUS, statusNotification(), type)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun refreshStatus() {
        nm.notify(ID_STATUS, statusNotification())
    }

    private fun statusNotification(): Notification {
        val text = if (monitoring) "Protection active : le micro surveille les bruits."
        else "Alerte SOS en cours."
        return NotificationCompat.Builder(this, CH_STATUS)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Protection")
            .setContentText(text)
            .setOngoing(true)
            .addAction(0, "Arrêter", servicePi(ACTION_STOP))
            .build()
    }

    private fun showCountdown() {
        nm.notify(
            ID_ALERT,
            NotificationCompat.Builder(this, CH_ALERT)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("Alerte dans $remaining s")
                .setContentText("Appuyez sur « Je vais bien » pour annuler.")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .addAction(0, "Je vais bien", servicePi(ACTION_CANCEL))
                .build()
        )
    }

    private fun servicePi(action: String): PendingIntent =
        PendingIntent.getService(
            this, action.hashCode(),
            Intent(this, GuardService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun buzz(ms: Long) {
        val v = getSystemService(Vibrator::class.java) ?: return
        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    }
}
