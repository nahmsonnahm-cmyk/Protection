package com.example.protection

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.telephony.SmsManager
import androidx.core.content.ContextCompat

/** Récupère la dernière position connue et envoie le SMS d'alerte. */
object AlertSender {

    fun lastLocation(context: Context): Location? {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return null
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        )
        return try {
            providers.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
                .maxByOrNull { it.time }
        } catch (e: SecurityException) {
            null
        }
    }

    /** @return true si le SMS a été confié au système. */
    fun send(context: Context, reason: String, isUpdate: Boolean = false): Boolean {
        val prefs = Prefs(context)
        if (!prefs.hasContact) return false
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED
        ) return false

        val who = prefs.userName.ifBlank { "Votre proche" }
        val loc = lastLocation(context)
        val place = if (loc != null) {
            "https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
        } else {
            "Position indisponible"
        }
        val text = if (isUpdate) {
            "MISE A JOUR - $who. Position : $place"
        } else {
            "ALERTE - $who est peut-etre en danger ($reason). Position : $place. Appelez-le/la tout de suite."
        }

        return try {
            val sms = if (Build.VERSION.SDK_INT >= 31) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION") SmsManager.getDefault()
            }
            val parts = sms.divideMessage(text)
            sms.sendMultipartTextMessage(prefs.contactPhone, null, parts, null, null)
            true
        } catch (e: Exception) {
            false
        }
    }
}
