# Protection – prototype Android (Kotlin)

Prototype : bouton SOS + détection de bruit fort + SMS avec position GPS.

## Ouvrir et lancer
1. Installer Android Studio (version récente).
2. File > Open > choisir le dossier `ProtectionApp`. Android Studio télécharge Gradle seul.
3. Brancher un vrai téléphone Android (8.0 ou plus) avec le mode développeur, puis Run.
4. Dans l'appli : saisir son prénom, le contact (numéro avec indicatif, ex. +225...), Enregistrer.
5. Activer la surveillance, accepter micro, position, SMS, notifications.
6. Pour tester sans risque : mettre d'abord TON propre numéro comme contact.

## Fichiers
- `MainActivity.kt` : écran unique, permissions, bouton SOS.
- `GuardService.kt` : service au premier plan, compte à rebours, SMS, suivi de position (5 fois, toutes les 2 min).
- `SoundDetector.kt` : mesure du volume. Point d'entrée pour brancher YAMNet (TensorFlow Lite) en V2.
- `AlertSender.kt` : dernière position connue + envoi du SMS.
- `Prefs.kt` : contact et sensibilité, stockés sur le téléphone.

## Limites connues
- Le détecteur réagit à tout bruit fort et soutenu (cri, mais aussi moto ou musique) : régler la sensibilité.
- La position est la dernière connue du système. V2 : demander des mises à jour GPS actives dans le service.
- Sur Tecno, Infinix, Xiaomi : désactiver l'optimisation de batterie et autoriser le démarrage automatique.
- Les SMS sont facturés par l'opérateur. Sur Android, la permission SMS est restreinte par Google Play pour la publication : prévoir le formulaire de déclaration, ou passer par l'appli SMS par défaut.
- Prototype non testé sur appareil à l'heure où il est livré : le compiler et le tester avant tout usage réel.
